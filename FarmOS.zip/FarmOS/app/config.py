
from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="FARMOS_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Server
    host: str  = "0.0.0.0"
    port: int  = 8000
    reload: bool = False

    # Logging
    log_level: str = "INFO"

    # API metadata
    app_title:       str = "FarmOS Leaf Vector API"
    app_version:     str = "1.0.0"
    app_description: str = (
        "AI-ready REST API that converts a leaf photograph into an LRTDC "
        "colour-vector payload for the FarmOS Deep Reinforcement Learning model."
    )

    # CORS — set to your Flutter app origin in production
    cors_origins: list[str] = ["*"]

    # Image processing limits
    max_image_bytes: int = 15 * 1024 * 1024   # 15 MB
    min_leaf_pixels: int = 50


# Singleton — import this everywhere
settings = Settings()