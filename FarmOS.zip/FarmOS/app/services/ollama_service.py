"""
FarmOS – Ollama AI Explanation Service
========================================
Takes the structured output from the recommendation engine + environmental
parameters and sends them to a locally running Ollama instance (gpt-oss:120b).

Ollama returns a descriptive, farmer-friendly paragraph that expands on the
rule-based recommendation with context, reasoning, and actionable next steps.

Flow:
  leaf_service  →  recommendation_engine  →  ollama_service  →  final response
                        (rule-based fix)         (LLM expand)

Usage:
  Ollama must be running locally:
    ollama serve                    # starts the server
    ollama pull gpt-oss:120b           # downloads the model (~2.5 GB)

  The service is called from leaf_router.py after the main analysis is done.
  If Ollama is unreachable, the service gracefully falls back to the
  rule-based recommendation so the API never breaks.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

OLLAMA_BASE_URL  = "http://localhost:11434"   # override with FARMOS_OLLAMA_URL env var
OLLAMA_MODEL     = "gpt-oss:120b"
OLLAMA_TIMEOUT_S = 60                          # seconds — LLM can be slow on CPU


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def _build_prompt(
    # From recommendation engine
    rule_recommendation: str,
    health_label:        str,
    health_score:        float,
    greenness_pct:       float,
    yellowing_pct:       float,
    necrosis_pct:        float,
    triggered_tags:      list[str],
    rule_id:             str,
    severity:            int,
    lrtdc_vector:        str,
    # Environmental inputs
    wind_force_ms:       Optional[float],
    humidity_pct:        Optional[float],
    temperature_c:       Optional[float],
    sunlight_lux:        Optional[float],
    # Farmer's question (optional)
    users_question:      Optional[str] = None,
    # Language for the response
    selected_language:   str = "English",
    # Groundwater context (optional — provided when lat/lon given)
    groundwater_stats:   Optional[dict] = None,
) -> str:
    """
    Build the prompt sent to gpt-oss:120b.
    Keep it structured so the model can reason clearly and stay on-topic.
    """

    # Format env block — skip None values cleanly
    env_lines = []
    if temperature_c  is not None: env_lines.append(f"  - Temperature:      {temperature_c}°C")
    if humidity_pct   is not None: env_lines.append(f"  - Humidity:         {humidity_pct}%")
    if wind_force_ms  is not None: env_lines.append(f"  - Wind speed:       {wind_force_ms} m/s")
    if sunlight_lux   is not None: env_lines.append(f"  - Sunlight:         {sunlight_lux} lux")
    env_block = "\n".join(env_lines) if env_lines else "  - No environmental data provided"

    tags_str = ", ".join(triggered_tags) if triggered_tags else "none"

    # Build groundwater block if stats were provided
    if groundwater_stats:
        gw = groundwater_stats.get("groundwater_potential", {})
        lat = groundwater_stats.get("lat", "N/A")
        lon = groundwater_stats.get("lon", "N/A")
        gw_block = (
            f"  - Farm location:     Lat {lat}, Lon {lon}\n"
            f"  - Very High GW zone: {gw.get('very_high_pct', 0):.1f}% of area\n"
            f"  - High GW zone:      {gw.get('high_pct', 0):.1f}% of area\n"
            f"  - Medium GW zone:    {gw.get('medium_pct', 0):.1f}% of area\n"
            f"  - Low GW zone:       {gw.get('low_pct', 0):.1f}% of area\n"
            f"  - Very Low GW zone:  {gw.get('very_low_pct', 0):.1f}% of area"
        )
    else:
        gw_block = "  - No groundwater data provided"

    # Build task block FIRST before the prompt string
    if users_question:
        task_block = (
            f"The farmer has asked: \"{users_question}\"\n\n"
            "Answer their specific question directly using the leaf diagnosis and environmental "
            "data above as context. Then in 1–2 sentences give the most important action they "
            "should take today."
        )
    else:
        task_block = (
            "Write a clear, descriptive explanation (3–5 sentences) for the farmer that:\n"
            "1. Tells them what is happening to their plant in simple language\n"
            "2. Explains WHY this is happening based on the leaf data and weather conditions\n"
            "3. Gives the most important action they should take TODAY\n"
            "4. Mentions what to watch for over the next few days"
        )

    prompt = f"""You are an expert agricultural advisor for small and medium-scale farmers in India.

A computer vision system has analysed a leaf photograph and produced the following structured diagnosis. Your job is to explain this diagnosis to the farmer in clear, practical, and empathetic language.

You MUST answer ONLY in {selected_language} language. Do not use any other language in your response.

--- LEAF DIAGNOSIS ---
Health status:     {health_label.upper()} (score: {health_score:.1f} / 100)
Severity level:    {severity} out of 5
Greenness:         {greenness_pct:.1f}% of leaf is green
Yellowing:         {yellowing_pct:.1f}% of leaf is yellowing
Browning/necrosis: {necrosis_pct:.1f}% of leaf is brown or dead
LRTDC colour vector: {lrtdc_vector}
Detected issues:   {tags_str}
Rule triggered:    {rule_id}

--- ENVIRONMENTAL CONDITIONS ---
{env_block}

--- GROUNDWATER CONDITIONS ---
{gw_block}

--- SYSTEM RECOMMENDATION ---
{rule_recommendation}

--- YOUR TASK ---
{task_block}

Write in a warm, helpful tone. Do NOT use bullet points. Write in plain paragraph form.
Do NOT repeat the numbers from the diagnosis verbatim — interpret them naturally.
Keep it under 150 words. Remember: your entire response must be in {selected_language} only.
"""
    return prompt.strip()


# ---------------------------------------------------------------------------
# Ollama HTTP call
# ---------------------------------------------------------------------------

def _call_ollama(prompt: str, base_url: str = OLLAMA_BASE_URL) -> str:
    """
    POST to Ollama's /api/generate endpoint (non-streaming).
    Returns the model's text response.
    Raises urllib.error.URLError if Ollama is unreachable.
    """
    url     = f"{base_url}/api/generate"
    payload = json.dumps({
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,          # wait for full response
        "options": {
            "temperature": 0.4,   # low temp = factual, consistent
            "top_p":       0.9,
            "num_predict": 200,   # ~120 words max
        },
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT_S) as resp:
        body = resp.read().decode("utf-8")

    data = json.loads(body)
    return data.get("response", "").strip()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_ai_explanation(
    # Recommendation engine output
    rule_recommendation: str,
    health_label:        str,
    health_score:        float,
    greenness_pct:       float,
    yellowing_pct:       float,
    necrosis_pct:        float,
    triggered_tags:      list[str],
    rule_id:             str,
    severity:            int,
    lrtdc_vector:        str,
    # Environmental inputs (optional)
    wind_force_ms:       Optional[float] = None,
    humidity_pct:        Optional[float] = None,
    temperature_c:       Optional[float] = None,
    sunlight_lux:        Optional[float] = None,
    # Farmer question (optional)
    users_question:      Optional[str] = None,
    # Language for the response
    selected_language:   str = "English",
    # Groundwater context (optional)
    groundwater_stats:   Optional[dict] = None,
    # Ollama config override
    ollama_base_url:     str = OLLAMA_BASE_URL,
) -> dict:
    """
    Call Ollama gpt-oss:120b and return a structured dict with:
      - ai_explanation : str   — the LLM-generated paragraph
      - model          : str   — model name used
      - ollama_available: bool — False if Ollama was unreachable (fallback used)
      - fallback_used  : bool  — True if the rule recommendation was used instead

    This function NEVER raises — if Ollama fails for any reason the
    rule-based recommendation is returned as the explanation so the
    main API response is never broken.
    """
    prompt = _build_prompt(
        rule_recommendation=rule_recommendation,
        health_label=health_label,
        health_score=health_score,
        greenness_pct=greenness_pct,
        yellowing_pct=yellowing_pct,
        necrosis_pct=necrosis_pct,
        triggered_tags=triggered_tags,
        rule_id=rule_id,
        severity=severity,
        lrtdc_vector=lrtdc_vector,
        wind_force_ms=wind_force_ms,
        humidity_pct=humidity_pct,
        temperature_c=temperature_c,
        sunlight_lux=sunlight_lux,
        users_question=users_question,
        selected_language=selected_language,
        groundwater_stats=groundwater_stats,
    )

    logger.debug("Ollama prompt:\n%s", prompt)

    try:
        explanation = _call_ollama(prompt, base_url=ollama_base_url)
        logger.info("Ollama response received (%d chars)", len(explanation))
        return {
            "ai_explanation":   explanation,
            "model":            OLLAMA_MODEL,
            "ollama_available": True,
            "fallback_used":    False,
        }

    except urllib.error.URLError as exc:
        logger.warning(
            "Ollama unreachable at %s (%s). Using rule-based fallback.",
            ollama_base_url, exc
        )
    except Exception as exc:
        logger.warning("Ollama call failed unexpectedly: %s. Using fallback.", exc)

    # Graceful fallback — return the rule recommendation as-is
    return {
        "ai_explanation":   rule_recommendation,
        "model":            "rule-based-fallback",
        "ollama_available": False,
        "fallback_used":    True,
    }